package com.snhu.mscs.cs600.sunrisefeature.data;

// Student: Malgorzata Debska

/**
 * Stores sunrise and sunset data returned by the Sunrise/Sunset API.
 */
public class SunriseSunsetData {

    private final String sunrise;
    private final String sunset;
    private final String date;
    private final String locationName;
    private final boolean successful;
    private final String message;

    public SunriseSunsetData(String sunrise, String sunset, String date,
            String locationName, boolean successful, String message) {
        this.sunrise = sunrise;
        this.sunset = sunset;
        this.date = date;
        this.locationName = locationName;
        this.successful = successful;
        this.message = message;
    }

    public static SunriseSunsetData success(String sunrise, String sunset,
            String date, String locationName) {
        return new SunriseSunsetData(sunrise, sunset, date, locationName, true,
                "Sunrise and sunset data loaded successfully.");
    }

    public static SunriseSunsetData failure(String message, String locationName) {
        return new SunriseSunsetData("Unavailable", "Unavailable", "Unavailable",
                locationName, false, message);
    }

    public String getSunrise() {
        return sunrise;
    }

    public String getSunset() {
        return sunset;
    }

    public String getDate() {
        return date;
    }

    public String getLocationName() {
        return locationName;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public String getMessage() {
        return message;
    }
}
