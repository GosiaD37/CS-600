package com.snhu.mscs.cs600.sunrisefeature.ui;

// Student: Malgorzata Debska

import java.time.LocalDate;

import com.snhu.mscs.cs600.base.ui.component.ViewToolbar;
import com.snhu.mscs.cs600.sunrisefeature.data.SunriseSunsetData;
import com.snhu.mscs.cs600.sunrisefeature.data.SunriseSunsetService;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

/**
 * Displays sunrise and sunset information from the external API.
 */
@Route("sunrise-sunset")
@AnonymousAllowed
@Menu(order = 2, icon = "vaadin:sun-o", title = "Sunrise/Sunset")
public class SunriseSunsetView extends VerticalLayout {

    private final SunriseSunsetService sunriseSunsetService;
    private final TextField locationNameField;
    private final NumberField latitudeField;
    private final NumberField longitudeField;
    private final DatePicker datePicker;
    private final Span resultText;

    public SunriseSunsetView(SunriseSunsetService sunriseSunsetService) {
        this.sunriseSunsetService = sunriseSunsetService;
        this.locationNameField = new TextField("Location Name");
        this.latitudeField = new NumberField("Latitude");
        this.longitudeField = new NumberField("Longitude");
        this.datePicker = new DatePicker("Date");
        this.resultText = new Span();

        configureView();
        add(new ViewToolbar("Sunrise/Sunset API Integration"), locationNameField,
                latitudeField, longitudeField, datePicker,
                new Button("Load Sunrise/Sunset Data", event -> loadApiData()),
                resultText);
    }

    private void configureView() {
        setSpacing(true);
        setPadding(true);

        locationNameField.setValue("Lincoln Memorial");
        latitudeField.setValue(38.88941);
        longitudeField.setValue(-77.05013);
        datePicker.setValue(LocalDate.now());

        resultText.getStyle().set("font-weight", "bold");
        resultText.setText("Click the button to request data from the Sunrise/Sunset API.");
    }

    private void loadApiData() {
        if (latitudeField.isEmpty() || longitudeField.isEmpty() || datePicker.isEmpty()) {
            Notification.show("Please enter latitude, longitude, and date.");
            return;
        }

        SunriseSunsetData data = sunriseSunsetService.getSunriseSunset(
                latitudeField.getValue(), longitudeField.getValue(),
                datePicker.getValue(), locationNameField.getValue());

        resultText.setText(String.format(
                "%s | Date: %s | Sunrise: %s | Sunset: %s | Status: %s",
                data.getLocationName(), data.getDate(), data.getSunrise(),
                data.getSunset(), data.getMessage()));

        if (!data.isSuccessful()) {
            Notification.show(data.getMessage());
        }
    }
}
