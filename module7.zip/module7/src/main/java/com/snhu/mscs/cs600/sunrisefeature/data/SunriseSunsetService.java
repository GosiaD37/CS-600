package com.snhu.mscs.cs600.sunrisefeature.data;

// Student: Malgorzata Debska

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Objects;
import java.util.function.Function;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Connects the application to the Sunrise/Sunset external API.
 */
@Service
public class SunriseSunsetService {

    private static final String API_ENDPOINT = "https://api.sunrisesunset.io/json";
    private static final String DEFAULT_TIME_ZONE = "America/Chicago";

    private final ObjectMapper objectMapper;
    private final Function<URI, String> apiFetcher;

    public SunriseSunsetService() {
        this.objectMapper = new ObjectMapper();
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        this.apiFetcher = uri -> sendRequest(client, uri);
    }

    SunriseSunsetService(Function<URI, String> apiFetcher) {
        this.objectMapper = new ObjectMapper();
        this.apiFetcher = Objects.requireNonNull(apiFetcher);
    }

    public SunriseSunsetData getSunriseSunset(double latitude, double longitude,
            LocalDate date, String locationName) {
        String safeLocation = isBlank(locationName) ? "Selected Location" : locationName;

        try {
            URI requestUri = buildUri(latitude, longitude, date);
            String responseBody = apiFetcher.apply(requestUri);
            JsonNode root = objectMapper.readTree(responseBody);

            if (!"OK".equalsIgnoreCase(root.path("status").asText())) {
                return SunriseSunsetData.failure(
                        "The external API returned an unsuccessful response.",
                        safeLocation);
            }

            JsonNode results = root.path("results");
            String sunrise = results.path("sunrise").asText("Unavailable");
            String sunset = results.path("sunset").asText("Unavailable");
            String responseDate = results.path("date").asText(date.toString());

            return SunriseSunsetData.success(sunrise, sunset, responseDate,
                    safeLocation);
        } catch (IllegalArgumentException ex) {
            return SunriseSunsetData.failure("Invalid latitude or longitude entered.",
                    safeLocation);
        } catch (Exception ex) {
            return SunriseSunsetData.failure(
                    "Unable to retrieve sunrise and sunset data. Please try again later.",
                    safeLocation);
        }
    }

    URI buildUri(double latitude, double longitude, LocalDate date) {
        validateCoordinates(latitude, longitude);
        String encodedTimeZone = URLEncoder.encode(DEFAULT_TIME_ZONE,
                StandardCharsets.UTF_8);
        String url = String.format("%s?lat=%s&lng=%s&date=%s&timezone=%s",
                API_ENDPOINT, latitude, longitude, date, encodedTimeZone);
        return URI.create(url);
    }

    private String sendRequest(HttpClient client, URI uri) {
        try {
            HttpRequest request = HttpRequest.newBuilder(uri)
                    .timeout(Duration.ofSeconds(15))
                    .GET()
                    .build();
            HttpResponse<String> response = client.send(request,
                    HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IOException("API returned HTTP status " + response.statusCode());
            }
            return response.body();
        } catch (IOException ex) {
            throw new IllegalStateException("Network error while calling API.", ex);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("API request was interrupted.", ex);
        }
    }

    private void validateCoordinates(double latitude, double longitude) {
        if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
            throw new IllegalArgumentException("Coordinates are outside valid range.");
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
