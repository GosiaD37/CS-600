package com.snhu.mscs.cs600.sunrisefeature.data;

// Student: Malgorzata Debska

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.URI;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Sunrise/Sunset API integration service.
 */
class SunriseSunsetServiceTest {

    @Test
    void getSunriseSunsetReturnsParsedApiData() {
        String successfulJson = """
                {
                  "results": {
                    "date": "2026-06-01",
                    "sunrise": "5:42:31 AM",
                    "sunset": "8:25:12 PM"
                  },
                  "status": "OK"
                }
                """;
        SunriseSunsetService service = new SunriseSunsetService(uri -> successfulJson);

        SunriseSunsetData data = service.getSunriseSunset(38.88941, -77.05013,
                LocalDate.of(2026, 6, 1), "Lincoln Memorial");

        assertTrue(data.isSuccessful());
        assertEquals("Lincoln Memorial", data.getLocationName());
        assertEquals("2026-06-01", data.getDate());
        assertEquals("5:42:31 AM", data.getSunrise());
        assertEquals("8:25:12 PM", data.getSunset());
    }

    @Test
    void getSunriseSunsetBuildsExpectedApiRequest() {
        AtomicReference<URI> capturedUri = new AtomicReference<>();
        SunriseSunsetService service = new SunriseSunsetService(uri -> {
            capturedUri.set(uri);
            return "{\"results\":{\"date\":\"2026-06-01\",\"sunrise\":\"5:42 AM\",\"sunset\":\"8:25 PM\"},\"status\":\"OK\"}";
        });

        service.getSunriseSunset(38.88941, -77.05013,
                LocalDate.of(2026, 6, 1), "Lincoln Memorial");

        String request = capturedUri.get().toString();
        assertTrue(request.contains("https://api.sunrisesunset.io/json"));
        assertTrue(request.contains("lat=38.88941"));
        assertTrue(request.contains("lng=-77.05013"));
        assertTrue(request.contains("date=2026-06-01"));
        assertTrue(request.contains("timezone=America%2FChicago"));
    }

    @Test
    void getSunriseSunsetReturnsFriendlyFailureForApiError() {
        SunriseSunsetService service = new SunriseSunsetService(uri ->
                "{\"results\":{},\"status\":\"INVALID_REQUEST\"}");

        SunriseSunsetData data = service.getSunriseSunset(38.88941, -77.05013,
                LocalDate.of(2026, 6, 1), "Lincoln Memorial");

        assertFalse(data.isSuccessful());
        assertEquals("Unavailable", data.getSunrise());
        assertEquals("Unavailable", data.getSunset());
    }

    @Test
    void getSunriseSunsetReturnsFriendlyFailureForInvalidCoordinates() {
        SunriseSunsetService service = new SunriseSunsetService(uri -> "{}");

        SunriseSunsetData data = service.getSunriseSunset(150.0, -77.05013,
                LocalDate.of(2026, 6, 1), "Bad Coordinates");

        assertFalse(data.isSuccessful());
        assertEquals("Invalid latitude or longitude entered.", data.getMessage());
    }
}
