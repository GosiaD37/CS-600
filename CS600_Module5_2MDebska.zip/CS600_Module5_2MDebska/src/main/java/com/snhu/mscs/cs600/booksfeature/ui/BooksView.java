package com.snhu.mscs.cs600.booksfeature.ui;

import com.snhu.mscs.cs600.base.ui.MainLayout;
import com.snhu.mscs.cs600.base.ui.component.ViewToolbar;
import com.snhu.mscs.cs600.booksfeature.data.Book;
import com.snhu.mscs.cs600.booksfeature.data.TestData;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

/**
 * Name: Malgorzata Debska
 * Course: CS 600
 * Assignment: Module Five Activity
 * Date: May 2026
 *
 * BooksView displays test book data in a read-only, scrollable Vaadin grid.
 */
@PageTitle("Books List")
@Route(value = "", layout = MainLayout.class)
public class BooksView extends VerticalLayout implements TestData {

    public BooksView() {
        add(new ViewToolbar("Books List"));

        Grid<Book> grid = new Grid<>(Book.class, false);
        grid.addColumn(Book::getTitle).setHeader("Title").setAutoWidth(true);
        grid.addColumn(Book::getAuthor).setHeader("Author").setAutoWidth(true);
        grid.addColumn(Book::getGenre).setHeader("Genre").setAutoWidth(true);
        grid.addColumn(Book::getYear).setHeader("Year").setAutoWidth(true);

        grid.setItems(getBooks());
        grid.setSelectionMode(Grid.SelectionMode.NONE);
        grid.setHeight("500px");
        grid.setWidthFull();

        add(grid);
        setSizeFull();
    }
}
