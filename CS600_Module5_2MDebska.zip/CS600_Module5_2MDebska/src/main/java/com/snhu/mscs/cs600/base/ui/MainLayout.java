package com.snhu.mscs.cs600.base.ui;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.theme.lumo.LumoUtility.AlignItems;
import com.vaadin.flow.theme.lumo.LumoUtility.Display;
import com.vaadin.flow.theme.lumo.LumoUtility.FontSize;
import com.vaadin.flow.theme.lumo.LumoUtility.FontWeight;
import com.vaadin.flow.theme.lumo.LumoUtility.Gap;
import com.vaadin.flow.theme.lumo.LumoUtility.Padding;
import com.snhu.mscs.cs600.booksfeature.ui.BooksView;

/**
 * Name: Malgorzata Debska
 * Course: CS 600
 * Assignment: Module Five Activity
 * Date: May 2026
 *
 * MainLayout creates the application shell. It includes a drawer-based
 * side navigation panel and a header with the application logo, title,
 * and student name.
 */
public class MainLayout extends AppLayout {

    public MainLayout() {
        setPrimarySection(Section.DRAWER);
        addToDrawer(createHeader(), new Scroller(createSideNav()));
    }

    private com.vaadin.flow.component.html.Div createHeader() {
        Image appLogo = new Image("images/module5-logo.svg", "Module5 logo");
        appLogo.setWidth("48px");
        appLogo.setHeight("48px");

        Span appName = new Span("Module5");
        appName.addClassNames(FontWeight.SEMIBOLD, FontSize.LARGE);

        Span studentName = new Span("Malgorzata Debska");
        studentName.addClassNames(FontSize.MEDIUM);

        com.vaadin.flow.component.html.Div header =
                new com.vaadin.flow.component.html.Div(appLogo, appName, studentName);

        header.addClassNames(
                Display.FLEX,
                Padding.MEDIUM,
                Gap.MEDIUM,
                AlignItems.CENTER
        );

        return header;
    }

    private SideNav createSideNav() {
        SideNav nav = new SideNav();
        nav.addItem(new SideNavItem("Books List", BooksView.class));
        return nav;
    }
}
