package com.snhu.mscs.cs600.base.ui.component;

import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;

/**
 * Name: Malgorzata Debska
 * Course: CS 600
 * Assignment: Module Five Activity
 * Date: May 2026
 *
 * Reusable toolbar component used to display the title of each view.
 */
public class ViewToolbar extends HorizontalLayout {

    public ViewToolbar(String title) {
        add(new H2(title));
        setWidthFull();
        setPadding(true);
        setAlignItems(Alignment.CENTER);
    }
}
