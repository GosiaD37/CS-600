package com.snhu.mscs.cs600.booksfeature.data;

import java.util.Arrays;
import java.util.List;

/**
 * Name: Malgorzata Debska
 * Course: CS 600
 * Assignment: Module Five Activity
 * Date: May 2026
 *
 * TestData provides placeholder book records for the read-only grid.
 */
public interface TestData {

    default List<Book> getBooks() {
        return Arrays.asList(
                new Book("The Great Gatsby", "F. Scott Fitzgerald", "Classic Fiction", 1925),
                new Book("To Kill a Mockingbird", "Harper Lee", "Classic Fiction", 1960),
                new Book("Clean Code", "Robert C. Martin", "Software Engineering", 2008),
                new Book("Effective Java", "Joshua Bloch", "Programming", 2018),
                new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "Software Design", 1994),
                new Book("Introduction to Algorithms", "Cormen, Leiserson, Rivest, Stein", "Computer Science", 2009),
                new Book("Database System Concepts", "Silberschatz, Korth, Sudarshan", "Databases", 2019),
                new Book("The Pragmatic Programmer", "Andrew Hunt and David Thomas", "Programming", 2019),
                new Book("Refactoring", "Martin Fowler", "Software Engineering", 2018),
                new Book("Head First Design Patterns", "Freeman and Robson", "Software Design", 2020),
                new Book("Java: The Complete Reference", "Herbert Schildt", "Programming", 2022),
                new Book("Spring in Action", "Craig Walls", "Java Frameworks", 2022)
        );
    }
}
