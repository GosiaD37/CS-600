package com.snhu.mscs.cs600;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Name: Malgorzata Debska
 * Course: CS 600
 * Assignment: Module Five Activity
 * Date: May 2026
 *
 * Main Spring Boot application class for the Module5 Vaadin application.
 */
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
