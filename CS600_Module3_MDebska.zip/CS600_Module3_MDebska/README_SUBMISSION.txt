CS 600 Module Three Activity Submission

Student: Malgorzata Debska
Course: CS 600
Assignment: Module Three Activity
Date: May 2026

Contents:
- src/main/java: Updated Java source files with student header comments
- src/main/resources/application.properties: HTTPS/TLS configuration
- keystore.p12: PKCS12 keystore required for HTTPS local testing
- pom.xml: Maven build file with Spring Security dependency
- submission_documents: Reflection and revised test plan Word documents

Testing notes:
Run from this folder with: mvn spring-boot:run
Public endpoint: https://localhost:8443/api/v1/version
Protected endpoint: https://localhost:8443/api/v1/names
Test credentials: namedUser / names.123
