-- Name: Malgorzata Debska
-- Course: CS-600
-- Date: June 15, 2026

-- Project: Sales Guru+
-- Description: PostgreSQL schema extension for Sales Guru+ product and invoice module.

CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY,
    sku VARCHAR(50) NOT NULL UNIQUE,
    product_name VARCHAR(150) NOT NULL,
    unit_price NUMERIC(10, 2) NOT NULL CHECK (unit_price >= 0),
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS invoices (
    invoice_id INTEGER PRIMARY KEY,
    customer_number INTEGER NOT NULL,
    representative_id INTEGER NOT NULL,
    invoice_date DATE NOT NULL DEFAULT CURRENT_DATE,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    CONSTRAINT fk_invoice_company FOREIGN KEY (customer_number) REFERENCES company(customer_number),
    CONSTRAINT fk_invoice_representative FOREIGN KEY (representative_id) REFERENCES representative(representative_id)
);

CREATE TABLE IF NOT EXISTS invoice_line_items (
    invoice_line_item_id SERIAL PRIMARY KEY,
    invoice_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price_at_sale NUMERIC(10, 2) NOT NULL CHECK (unit_price_at_sale >= 0),
    CONSTRAINT fk_line_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id),
    CONSTRAINT fk_line_product FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE INDEX IF NOT EXISTS idx_invoices_customer_number ON invoices(customer_number);
CREATE INDEX IF NOT EXISTS idx_invoice_line_items_invoice_id ON invoice_line_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku);
