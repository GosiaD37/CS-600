<!--
Name: Malgorzata Debska
Course: CS-600
Date: June 15, 2026
Project: Sales Guru+
Description: Project README for the completed Sales Guru+ Java development tree.
-->
# Sales Guru+ Java Module
Project: Sales Guru+

## Overview
This folder contains a Java implementation of the Sales Guru+ module. The module adds product storage, invoice storage, invoice line items, invoice total aggregation, external authentication integration, and a basic graphical-style console view.

## Features Implemented
- Product model and service
- Invoice model and service
- Invoice line item aggregation
- External authentication provider interface
- Basic visualization through console tables
- Repository interfaces for maintainability
- In-memory repositories for testing/demo
- PostgreSQL schema extension
- JUnit tests for functionality and edge cases
- Requirements traceability matrix
- Expanded test plan

## How to Run
From this folder, run:

```bash
mvn test
mvn exec:java -Dexec.mainClass="com.acme.salesguruplus.SalesGuruPlusApplication"
```

If the Codio environment does not include the Maven exec plugin, the application can also be run directly from the IDE by running:

`com.acme.salesguruplus.SalesGuruPlusApplication`

## Notes
The in-memory repositories are included so the module can be tested without requiring a live database. The `sql/schema.sql` file contains the PostgreSQL database tables that would be used for production integration with the existing Sales Guru database.
