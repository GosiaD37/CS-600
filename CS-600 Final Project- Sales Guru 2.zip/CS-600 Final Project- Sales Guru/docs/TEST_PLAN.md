<!--
Name: Malgorzata Debska
Course: CS-600
Date: June 15, 2026
Project: Sales Guru+
Description: Expanded test plan for the Sales Guru+ Java module.
-->
# Sales Guru+ Expanded Test Plan

## Functional Tests
1. Create a product and verify it appears in the active product list.
2. Reject duplicate product SKUs.
3. Create an invoice and verify it is associated with a customer and representative.
4. Add products to an invoice and verify invoice totals aggregate correctly.
5. Submit an invoice only when it contains at least one line item.
6. Authenticate users through the external authentication provider.
7. Display product and invoice lists through the view layer.

## Performance Tests
1. Retrieve invoices for a customer in under two seconds under normal load.
2. Verify product list retrieval remains responsive as products increase.
3. Monitor database timeout rate after adding invoice tables and indexes.

## Edge Case Tests
1. Reject blank product names.
2. Reject negative prices.
3. Reject zero or negative quantities.
4. Reject empty invoices during submission.
5. Reject duplicate invoice IDs.
6. Reject blank authentication fields.

## Regression Tests
1. Verify unique customer numbers still work.
2. Verify unique representative IDs still work.
3. Verify representatives remain linked to one company.
4. Verify authentication is still required.
5. Verify HTTPS/encrypted communication remains required in production.
6. Verify company and representative lists still display correctly.
