<!--
Name: Malgorzata Debska
Course: CS-600
Date: June 15, 2026
Project: Sales Guru+
Description: Requirements traceability and verification matrix for Sales Guru+.
-->
# Sales Guru+ Requirements Traceability Matrix

| Requirement | Implementation | Verification Method |
|---|---|---|
| Store invoices in the database | Invoice model, InvoiceRepository, invoices table | Unit and integration tests |
| Store items for sale | Product model, ProductRepository, products table | ProductServiceTest |
| Aggregate invoice line items | InvoiceLineItem and Invoice.calculateTotal() | InvoiceServiceTest |
| Use external authentication | AuthenticationProvider and AuthenticationService | AuthenticationServiceTest |
| Visualize lists of data | SalesGuruPlusConsoleView | Manual UI/console verification |
| Preserve company and representative compatibility | Company and Representative models remain separated | Regression testing |
| Prevent invalid input | Constructor and service validation | Edge-case unit tests |
| Support future expansion | Layered service/repository/model design | Code review and design review |
