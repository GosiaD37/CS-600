/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.auth;

public class ExternalDatabaseAuthenticationProvider implements AuthenticationProvider {
    @Override
    public boolean authenticate(String username, String password) {
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            return false;
        }

        // In production, this method would call the external authentication database.
        // The demonstration rule avoids hard-coded production credentials.
        return username.trim().length() >= 4 && password.length() >= 8;
    }
}
