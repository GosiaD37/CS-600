/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus;

import com.acme.salesguruplus.auth.ExternalDatabaseAuthenticationProvider;
import com.acme.salesguruplus.model.Invoice;
import com.acme.salesguruplus.model.Product;
import com.acme.salesguruplus.repository.InMemoryInvoiceRepository;
import com.acme.salesguruplus.repository.InMemoryProductRepository;
import com.acme.salesguruplus.service.AuthenticationService;
import com.acme.salesguruplus.service.InvoiceService;
import com.acme.salesguruplus.service.ProductService;
import com.acme.salesguruplus.ui.SalesGuruPlusConsoleView;

import java.math.BigDecimal;

public class SalesGuruPlusApplication {
    public static void main(String[] args) {
        AuthenticationService authenticationService = new AuthenticationService(new ExternalDatabaseAuthenticationProvider());
        boolean authenticated = authenticationService.login("salesuser", "SecurePass123");

        if (!authenticated) {
            System.out.println("Authentication failed. Access denied.");
            return;
        }

        ProductService productService = new ProductService(new InMemoryProductRepository());
        InvoiceService invoiceService = new InvoiceService(new InMemoryInvoiceRepository());
        SalesGuruPlusConsoleView view = new SalesGuruPlusConsoleView();

        Product planner = productService.createProduct(1, "PLAN-001", "Custom Sales Planner", new BigDecimal("49.99"));
        Product cards = productService.createProduct(2, "CARD-001", "Premium Contact Cards", new BigDecimal("129.99"));

        Invoice invoice = invoiceService.createInvoice(1001, 501, 2001);
        invoiceService.addProductToInvoice(invoice, planner, 2);
        invoiceService.addProductToInvoice(invoice, cards, 1);
        invoiceService.submitInvoice(invoice);

        view.showProducts(productService.listActiveProducts());
        view.showInvoices(invoiceService.getInvoicesForCustomer(501));
    }
}
