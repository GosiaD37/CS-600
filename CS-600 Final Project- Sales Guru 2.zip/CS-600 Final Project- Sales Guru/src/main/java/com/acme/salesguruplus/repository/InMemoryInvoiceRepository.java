/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.repository;

import com.acme.salesguruplus.model.Invoice;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryInvoiceRepository implements InvoiceRepository {
    private final Map<Integer, Invoice> invoices = new ConcurrentHashMap<>();

    @Override
    public void save(Invoice invoice) {
        if (invoice == null) {
            throw new IllegalArgumentException("Invoice cannot be null.");
        }
        invoices.put(invoice.getInvoiceId(), invoice);
    }

    @Override
    public Optional<Invoice> findById(int invoiceId) {
        return Optional.ofNullable(invoices.get(invoiceId));
    }

    @Override
    public List<Invoice> findByCustomerNumber(int customerNumber) {
        List<Invoice> results = new ArrayList<>();
        for (Invoice invoice : invoices.values()) {
            if (invoice.getCustomerNumber() == customerNumber) {
                results.add(invoice);
            }
        }
        return results;
    }
}
