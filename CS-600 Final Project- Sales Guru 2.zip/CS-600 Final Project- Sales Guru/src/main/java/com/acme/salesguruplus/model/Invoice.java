/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Invoice {
    private final int invoiceId;
    private final int customerNumber;
    private final int representativeId;
    private final LocalDate invoiceDate;
    private InvoiceStatus status;
    private final List<InvoiceLineItem> lineItems;

    public Invoice(int invoiceId, int customerNumber, int representativeId, LocalDate invoiceDate) {
        if (invoiceId <= 0) {
            throw new IllegalArgumentException("Invoice ID must be greater than zero.");
        }
        if (customerNumber <= 0) {
            throw new IllegalArgumentException("Customer number must be greater than zero.");
        }
        if (representativeId <= 0) {
            throw new IllegalArgumentException("Representative ID must be greater than zero.");
        }
        this.invoiceId = invoiceId;
        this.customerNumber = customerNumber;
        this.representativeId = representativeId;
        this.invoiceDate = invoiceDate == null ? LocalDate.now() : invoiceDate;
        this.status = InvoiceStatus.DRAFT;
        this.lineItems = new ArrayList<>();
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public int getRepresentativeId() {
        return representativeId;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public InvoiceStatus getStatus() {
        return status;
    }

    public void setStatus(InvoiceStatus status) {
        if (status == null) {
            throw new IllegalArgumentException("Status is required.");
        }
        this.status = status;
    }

    public void addLineItem(InvoiceLineItem item) {
        if (item == null) {
            throw new IllegalArgumentException("Invoice line item cannot be null.");
        }
        if (status != InvoiceStatus.DRAFT) {
            throw new IllegalStateException("Only draft invoices can be changed.");
        }
        lineItems.add(item);
    }

    public List<InvoiceLineItem> getLineItems() {
        return Collections.unmodifiableList(lineItems);
    }

    public BigDecimal calculateTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (InvoiceLineItem item : lineItems) {
            total = total.add(item.getLineTotal());
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Invoice invoice)) return false;
        return invoiceId == invoice.invoiceId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(invoiceId);
    }
}
