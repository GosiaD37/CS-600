/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.auth;

public interface AuthenticationProvider {
    boolean authenticate(String username, String password);
}
