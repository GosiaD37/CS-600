/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.repository;

import com.acme.salesguruplus.model.Product;

import java.util.List;
import java.util.Optional;

public interface ProductRepository {
    void save(Product product);
    Optional<Product> findById(int productId);
    Optional<Product> findBySku(String sku);
    List<Product> findAllActive();
}
