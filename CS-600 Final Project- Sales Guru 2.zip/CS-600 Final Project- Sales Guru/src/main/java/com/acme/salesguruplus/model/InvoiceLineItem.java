/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class InvoiceLineItem {
    private final Product product;
    private final int quantity;
    private final BigDecimal unitPriceAtSale;

    public InvoiceLineItem(Product product, int quantity) {
        this(product, quantity, product == null ? null : product.getUnitPrice());
    }

    public InvoiceLineItem(Product product, int quantity, BigDecimal unitPriceAtSale) {
        if (product == null) {
            throw new IllegalArgumentException("Product is required.");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }
        if (unitPriceAtSale == null || unitPriceAtSale.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Unit price at sale cannot be negative.");
        }
        this.product = product;
        this.quantity = quantity;
        this.unitPriceAtSale = unitPriceAtSale.setScale(2, RoundingMode.HALF_UP);
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public BigDecimal getUnitPriceAtSale() {
        return unitPriceAtSale;
    }

    public BigDecimal getLineTotal() {
        return unitPriceAtSale.multiply(BigDecimal.valueOf(quantity)).setScale(2, RoundingMode.HALF_UP);
    }
}
