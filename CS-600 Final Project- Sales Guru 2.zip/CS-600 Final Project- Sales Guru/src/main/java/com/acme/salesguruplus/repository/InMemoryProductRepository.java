/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.repository;

import com.acme.salesguruplus.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryProductRepository implements ProductRepository {
    private final Map<Integer, Product> products = new ConcurrentHashMap<>();

    @Override
    public void save(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }
        products.put(product.getProductId(), product);
    }

    @Override
    public Optional<Product> findById(int productId) {
        return Optional.ofNullable(products.get(productId));
    }

    @Override
    public Optional<Product> findBySku(String sku) {
        if (sku == null) {
            return Optional.empty();
        }
        return products.values().stream()
                .filter(product -> product.getSku().equalsIgnoreCase(sku.trim()))
                .findFirst();
    }

    @Override
    public List<Product> findAllActive() {
        List<Product> activeProducts = new ArrayList<>();
        for (Product product : products.values()) {
            if (product.isActive()) {
                activeProducts.add(product);
            }
        }
        return activeProducts;
    }
}
