/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.model;

import java.util.Objects;

public class Company {
    private final int customerNumber;
    private final String companyName;

    public Company(int customerNumber, String companyName) {
        if (customerNumber <= 0) {
            throw new IllegalArgumentException("Customer number must be greater than zero.");
        }
        if (companyName == null || companyName.isBlank()) {
            throw new IllegalArgumentException("Company name is required.");
        }
        this.customerNumber = customerNumber;
        this.companyName = companyName.trim();
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Company company)) return false;
        return customerNumber == company.customerNumber;
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerNumber);
    }

    @Override
    public String toString() {
        return customerNumber + " - " + companyName;
    }
}
