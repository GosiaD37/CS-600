/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.service;

import com.acme.salesguruplus.auth.AuthenticationProvider;

public class AuthenticationService {
    private final AuthenticationProvider authenticationProvider;

    public AuthenticationService(AuthenticationProvider authenticationProvider) {
        if (authenticationProvider == null) {
            throw new IllegalArgumentException("Authentication provider is required.");
        }
        this.authenticationProvider = authenticationProvider;
    }

    public boolean login(String username, String password) {
        return authenticationProvider.authenticate(username, password);
    }
}
