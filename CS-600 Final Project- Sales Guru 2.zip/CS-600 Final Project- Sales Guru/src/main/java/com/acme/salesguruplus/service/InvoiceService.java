/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.service;

import com.acme.salesguruplus.model.Invoice;
import com.acme.salesguruplus.model.InvoiceLineItem;
import com.acme.salesguruplus.model.InvoiceStatus;
import com.acme.salesguruplus.model.Product;
import com.acme.salesguruplus.repository.InvoiceRepository;

import java.time.LocalDate;
import java.util.List;

public class InvoiceService {
    private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        if (invoiceRepository == null) {
            throw new IllegalArgumentException("Invoice repository is required.");
        }
        this.invoiceRepository = invoiceRepository;
    }

    public Invoice createInvoice(int invoiceId, int customerNumber, int representativeId) {
        if (invoiceRepository.findById(invoiceId).isPresent()) {
            throw new IllegalArgumentException("Invoice ID already exists.");
        }
        Invoice invoice = new Invoice(invoiceId, customerNumber, representativeId, LocalDate.now());
        invoiceRepository.save(invoice);
        return invoice;
    }

    public void addProductToInvoice(Invoice invoice, Product product, int quantity) {
        if (invoice == null) {
            throw new IllegalArgumentException("Invoice is required.");
        }
        invoice.addLineItem(new InvoiceLineItem(product, quantity));
        invoiceRepository.save(invoice);
    }

    public void submitInvoice(Invoice invoice) {
        if (invoice == null) {
            throw new IllegalArgumentException("Invoice is required.");
        }
        if (invoice.getLineItems().isEmpty()) {
            throw new IllegalStateException("Invoice must include at least one line item before submission.");
        }
        invoice.setStatus(InvoiceStatus.SUBMITTED);
        invoiceRepository.save(invoice);
    }

    public List<Invoice> getInvoicesForCustomer(int customerNumber) {
        if (customerNumber <= 0) {
            throw new IllegalArgumentException("Customer number must be greater than zero.");
        }
        return invoiceRepository.findByCustomerNumber(customerNumber);
    }
}
