/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

public final class MoneyFormatter {
    private MoneyFormatter() {
        // Utility class should not be instantiated.
    }

    public static String format(BigDecimal amount) {
        if (amount == null) {
            return "$0.00";
        }
        return NumberFormat.getCurrencyInstance(Locale.US).format(amount);
    }
}
