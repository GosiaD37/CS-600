/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.repository;

import com.acme.salesguruplus.model.Invoice;

import java.util.List;
import java.util.Optional;

public interface InvoiceRepository {
    void save(Invoice invoice);
    Optional<Invoice> findById(int invoiceId);
    List<Invoice> findByCustomerNumber(int customerNumber);
}
