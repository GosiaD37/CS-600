/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.service;

import com.acme.salesguruplus.model.Product;
import com.acme.salesguruplus.repository.ProductRepository;

import java.math.BigDecimal;
import java.util.List;

public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        if (productRepository == null) {
            throw new IllegalArgumentException("Product repository is required.");
        }
        this.productRepository = productRepository;
    }

    public Product createProduct(int productId, String sku, String productName, BigDecimal unitPrice) {
        if (productRepository.findById(productId).isPresent()) {
            throw new IllegalArgumentException("Product ID already exists.");
        }
        if (productRepository.findBySku(sku).isPresent()) {
            throw new IllegalArgumentException("Product SKU already exists.");
        }
        Product product = new Product(productId, sku, productName, unitPrice, true);
        productRepository.save(product);
        return product;
    }

    public List<Product> listActiveProducts() {
        return productRepository.findAllActive();
    }
}
