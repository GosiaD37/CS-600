/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.model;

import java.util.Objects;

public class Representative {
    private final int representativeId;
    private final int customerNumber;
    private final String firstName;
    private final String lastName;

    public Representative(int representativeId, int customerNumber, String firstName, String lastName) {
        if (representativeId <= 0) {
            throw new IllegalArgumentException("Representative ID must be greater than zero.");
        }
        if (customerNumber <= 0) {
            throw new IllegalArgumentException("Customer number must be greater than zero.");
        }
        if (firstName == null || firstName.isBlank() || lastName == null || lastName.isBlank()) {
            throw new IllegalArgumentException("Representative first and last name are required.");
        }
        this.representativeId = representativeId;
        this.customerNumber = customerNumber;
        this.firstName = firstName.trim();
        this.lastName = lastName.trim();
    }

    public int getRepresentativeId() {
        return representativeId;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Representative that)) return false;
        return representativeId == that.representativeId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(representativeId);
    }
}
