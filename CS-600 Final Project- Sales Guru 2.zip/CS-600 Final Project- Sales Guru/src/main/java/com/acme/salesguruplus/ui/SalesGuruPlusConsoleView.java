/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.ui;

import com.acme.salesguruplus.model.Invoice;
import com.acme.salesguruplus.model.Product;

import java.util.List;

public class SalesGuruPlusConsoleView {
    public void showProducts(List<Product> products) {
        System.out.println("\n=== Sales Guru+ Product List ===");
        System.out.printf("%-10s %-15s %-30s %-10s%n", "ID", "SKU", "Product", "Price");
        for (Product product : products) {
            System.out.printf("%-10d %-15s %-30s $%-10s%n",
                    product.getProductId(),
                    product.getSku(),
                    product.getProductName(),
                    product.getUnitPrice());
        }
    }

    public void showInvoices(List<Invoice> invoices) {
        System.out.println("\n=== Sales Guru+ Invoice List ===");
        System.out.printf("%-10s %-15s %-18s %-12s %-10s%n", "Invoice", "Customer", "Representative", "Status", "Total");
        for (Invoice invoice : invoices) {
            System.out.printf("%-10d %-15d %-18d %-12s $%-10s%n",
                    invoice.getInvoiceId(),
                    invoice.getCustomerNumber(),
                    invoice.getRepresentativeId(),
                    invoice.getStatus(),
                    invoice.calculateTotal());
        }
    }
}
