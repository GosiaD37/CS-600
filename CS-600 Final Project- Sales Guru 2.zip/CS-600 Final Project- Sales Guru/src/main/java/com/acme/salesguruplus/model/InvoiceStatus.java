/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.model;

public enum InvoiceStatus {
    DRAFT,
    SUBMITTED,
    PAID,
    CANCELLED
}
