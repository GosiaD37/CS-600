/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.service;

import com.acme.salesguruplus.model.Invoice;
import com.acme.salesguruplus.model.InvoiceStatus;
import com.acme.salesguruplus.model.Product;
import com.acme.salesguruplus.repository.InMemoryInvoiceRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceServiceTest {
    @Test
    void invoiceTotalAggregatesLineItemsCorrectly() {
        InvoiceService invoiceService = new InvoiceService(new InMemoryInvoiceRepository());
        Product product = new Product(1, "TEST-001", "Test Product", new BigDecimal("10.50"), true);

        Invoice invoice = invoiceService.createInvoice(1, 101, 201);
        invoiceService.addProductToInvoice(invoice, product, 3);

        assertEquals(new BigDecimal("31.50"), invoice.calculateTotal());
    }

    @Test
    void invoiceRejectsNegativeQuantity() {
        InvoiceService invoiceService = new InvoiceService(new InMemoryInvoiceRepository());
        Product product = new Product(1, "TEST-001", "Test Product", new BigDecimal("10.50"), true);
        Invoice invoice = invoiceService.createInvoice(1, 101, 201);

        assertThrows(IllegalArgumentException.class, () -> invoiceService.addProductToInvoice(invoice, product, -1));
    }

    @Test
    void invoiceCannotBeSubmittedWithoutLineItems() {
        InvoiceService invoiceService = new InvoiceService(new InMemoryInvoiceRepository());
        Invoice invoice = invoiceService.createInvoice(1, 101, 201);

        assertThrows(IllegalStateException.class, () -> invoiceService.submitInvoice(invoice));
    }

    @Test
    void submittedInvoiceStatusIsUpdated() {
        InvoiceService invoiceService = new InvoiceService(new InMemoryInvoiceRepository());
        Product product = new Product(1, "TEST-001", "Test Product", new BigDecimal("10.50"), true);
        Invoice invoice = invoiceService.createInvoice(1, 101, 201);
        invoiceService.addProductToInvoice(invoice, product, 1);

        invoiceService.submitInvoice(invoice);

        assertEquals(InvoiceStatus.SUBMITTED, invoice.getStatus());
    }
}
