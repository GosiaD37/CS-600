/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.service;

import com.acme.salesguruplus.repository.InMemoryProductRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class ProductServiceTest {
    @Test
    void productCanBeCreatedAndListed() {
        ProductService productService = new ProductService(new InMemoryProductRepository());
        productService.createProduct(1, "SKU-001", "Planner", new BigDecimal("25.00"));

        assertEquals(1, productService.listActiveProducts().size());
    }

    @Test
    void duplicateSkuIsRejected() {
        ProductService productService = new ProductService(new InMemoryProductRepository());
        productService.createProduct(1, "SKU-001", "Planner", new BigDecimal("25.00"));

        assertThrows(IllegalArgumentException.class,
                () -> productService.createProduct(2, "SKU-001", "Other Planner", new BigDecimal("30.00")));
    }

    @Test
    void negativeProductPriceIsRejected() {
        ProductService productService = new ProductService(new InMemoryProductRepository());

        assertThrows(IllegalArgumentException.class,
                () -> productService.createProduct(1, "SKU-001", "Planner", new BigDecimal("-1.00")));
    }
}
