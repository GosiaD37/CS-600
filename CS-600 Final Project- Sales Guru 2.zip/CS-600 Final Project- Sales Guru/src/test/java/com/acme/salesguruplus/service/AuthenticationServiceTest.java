/*
 * Name: Malgorzata Debska
 * Course: CS-600
 * Date: June 15, 2026
 */

package com.acme.salesguruplus.service;

import com.acme.salesguruplus.auth.ExternalDatabaseAuthenticationProvider;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AuthenticationServiceTest {
    @Test
    void validExternalLoginReturnsTrue() {
        AuthenticationService service = new AuthenticationService(new ExternalDatabaseAuthenticationProvider());

        assertTrue(service.login("salesuser", "SecurePass123"));
    }

    @Test
    void blankLoginReturnsFalse() {
        AuthenticationService service = new AuthenticationService(new ExternalDatabaseAuthenticationProvider());

        assertFalse(service.login("", ""));
    }
}
